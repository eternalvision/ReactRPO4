export const Friends = () => {
    return (
        <section className="Friends">
            <h1>Friends</h1>
        </section>
    );
};

import React from "react";
import { Link } from "react-router-dom";

export const News = () => {
    return (
        <section className="News">
            <h1>News</h1>
            <Link to="/news/london">London</Link>
            <Link to="/news/berlin">Berlin</Link>
            <Link to="/news/paris">Paris</Link>
        </section>
    );
};

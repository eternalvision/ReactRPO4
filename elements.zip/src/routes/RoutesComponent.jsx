import React from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import { RouteComponents } from "../routeComponents/RouteComponents";

const { Friends, News, Profile } = RouteComponents;

const London = () => {
    return <h2>London</h2>;
};

const Berlin = () => {
    return <h2>Berlin</h2>;
};

const Paris = () => {
    return <h2>Paris</h2>;
};

const ProfileContent = () => {
    return (
        <ul>
            <li>Item</li>
            <li>Item</li>
            <li>Item</li>
            <li>Item</li>
        </ul>
    );
};

export const RouteComponent = () => {
    return (
        <Routes>
            <Route path="*" element={<Navigate to="/" />} />
            <Route path="/" element={<News />} />
            <Route path="/friends" element={<Friends />} />
            <Route path="/news" element={<News />} />
            <Route path="/news/london" element={<London />} />
            <Route path="/news/berlin" element={<Berlin />} />
            <Route path="/news/paris" element={<Paris />} />
            <Route path="/profile/:userName" element={<Profile />} />
        </Routes>
    );
};

export const MainComponent = ({ RouteComponent }) => {
    return (
        <main className="Main">
            wlpwmbpwmb
            <p>wpjg2k</p>
            <RouteComponent />
        </main>
    );
};

export const News = () => {
    return (
        <section className="News">
            <h1>News</h1>
        </section>
    );
};

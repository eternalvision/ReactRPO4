export const Profile = ({ ProfileContent }) => {
    return (
        <section className="Profile">
            <h1>Profile</h1>
            <ProfileContent />
        </section>
    );
};

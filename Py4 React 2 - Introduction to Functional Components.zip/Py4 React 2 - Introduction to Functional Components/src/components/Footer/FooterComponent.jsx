export const FooterComponent = () => {
    return <footer className="Footer"></footer>;
};

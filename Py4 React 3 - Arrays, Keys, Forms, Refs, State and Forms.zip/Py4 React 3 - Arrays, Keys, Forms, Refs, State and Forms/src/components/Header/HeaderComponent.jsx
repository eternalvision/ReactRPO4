export const HeaderComponent = () => {
    return <header className="Header"></header>;
};
